/*
 * Author: Landon Fuller <landonf@plausiblelabs.com>
 *
 * Copyright (c) 2008-2013 Plausible Labs Cooperative, Inc.
 * All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

#ifndef OKCRASH_ASYNC_IMAGE_LIST_H
#define OKCRASH_ASYNC_IMAGE_LIST_H

#include <stdint.h>
#include <stdbool.h>

#include "OKCrashAsyncMachOImage.h"

/*
 * NOTE: We keep this code C-compatible for backwards-compatibility purposes. If the entirity
 * of the codebase migrates to C/C++/Objective-C++, we can drop the C compatibility support
 * used here.
 */
#ifdef __cplusplus
#include "OKCrashAsyncLinkedList.hpp"
#endif
    
#ifdef __cplusplus
extern "C" {
#endif

typedef struct okcrash_async_image okcrash_async_image_t;

/**
 * @internal
 * @ingroup okcrash_async_image
 *
 * Async-safe binary image list element.
 */
struct okcrash_async_image {
    /** The binary image. */
    okcrash_async_macho_t macho_image;

    /** A borrowed, circular reference to the backing list node. */
#ifdef __cplusplus
    okcrash::async::async_list<okcrash_async_image_t *>::node * volatile _node;
#else
    void * volatile _node;
#endif
};

/**
 * @internal
 * @ingroup okcrash_async_image
 *
 * Async-safe binary image list. May be used to iterate over the binary images currently
 * available in-process.
 */
typedef struct okcrash_async_image_list {    
    /** The Mach task in which all Mach-O images can be found */
    mach_port_t task;

    /** The backing list */
#ifdef __cplusplus
    okcrash::async::async_list<okcrash_async_image_t *> *_list;
#else
    void *_list;
#endif
} okcrash_async_image_list_t;

void okcrash_nasync_image_list_init (okcrash_async_image_list_t *list, mach_port_t task);
void okcrash_nasync_image_list_free (okcrash_async_image_list_t *list);
void okcrash_nasync_image_list_append (okcrash_async_image_list_t *list, ok_vm_address_t header, const char *name);

void okcrash_nasync_image_list_remove (okcrash_async_image_list_t *list, ok_vm_address_t header);

void okcrash_async_image_list_set_reading (okcrash_async_image_list_t *list, bool enable);

okcrash_async_image_t *okcrash_async_image_containing_address (okcrash_async_image_list_t *list, ok_vm_address_t address);
okcrash_async_image_t *okcrash_async_image_list_next (okcrash_async_image_list_t *list, okcrash_async_image_t *current);
    
#ifdef __cplusplus
}
#endif

#endif /* OKCRASH_ASYNC_IMAGE_LIST_H */

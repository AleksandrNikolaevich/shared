/*
 * Author: Landon Fuller <landonf@plausiblelabs.com>
 *
 * Copyright (c) 2008-2013 Plausible Labs Cooperative, Inc.
 * All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

#ifndef OKCRASH_SYSCTL_H
#define OKCRASH_SYSCTL_H

#if __has_include(<CrashReporter/OKCrashNamespace.h>)
#import <CrashReporter/OKCrashNamespace.h>
#else
#import "OKCrashNamespace.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif

#include <stdlib.h>
#include <stdbool.h>

#include <sys/types.h>
#include <sys/sysctl.h>

/**
 * @internal
 * @ingroup okcrash_host
 *
 * @{
 */

char *okcrash_sysctl_string (const char *name);
bool okcrash_sysctl_int (const char *name, int *result);

size_t okcrash_sysctl_valid_utf8_bytes_max (const unsigned char *s, size_t maxlen);
size_t okcrash_sysctl_valid_utf8_bytes (const unsigned char *s);

/*
 * @}
 */

#ifdef __cplusplus
}
#endif

#endif /* OKCRASH_SYSCTL_H */

/*
 * Copyright (c) 2013 Plausible Labs Cooperative, Inc.
 * All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

#ifndef OKCRASH_FRAME_COMPACTUNWIND_H
#define OKCRASH_FRAME_COMPACTUNWIND_H

#include "OKCrashFeatureConfig.h"
#include "OKCrashFrameWalker.h"
#include "OKCrashAsyncCompactUnwindEncoding.h"

#if OKCRASH_FEATURE_UNWIND_DWARF

#ifdef __cplusplus
extern "C" {
#endif

okframe_error_t okframe_cursor_read_compact_unwind (task_t task,
                                                    okcrash_async_image_list_t *image_list,
                                                    const okframe_stackframe_t *current_frame,
                                                    const okframe_stackframe_t *previous_frame,
                                                    okframe_stackframe_t *next_frame);
    
#ifdef __cplusplus
}
#endif

#endif /* OKCRASH_FEATURE_UNWIND_DWARF */
#endif /* OKCRASH_FRAME_COMPACTUNWIND_H */

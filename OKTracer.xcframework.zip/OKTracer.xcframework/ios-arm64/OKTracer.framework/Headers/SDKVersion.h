//
//  SDKVersion.h
//  OKTracer
//
//  Created by david.chupreev on 01.03.2024.
//

#import <Foundation/Foundation.h>

#ifndef OKTRACER_VERSION
#define OKTRACER_VERSION @"1.0.38"
#endif

static NSString * const OKTracerVersion = OKTRACER_VERSION;

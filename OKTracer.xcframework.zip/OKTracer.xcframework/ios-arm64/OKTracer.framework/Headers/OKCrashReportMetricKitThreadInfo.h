//
//  OKCrashReportMetricKitThreadInfo.h
//  OKTracer
//
//  Created by david.chupreev on 12.12.2023.
//

#import <Foundation/Foundation.h>

#if __has_include(<CrashReporter/OKCrashNamespace.h>)
#import <CrashReporter/OKCrashNamespace.h>
#else
#import "OKCrashNamespace.h"
#endif

NS_ASSUME_NONNULL_BEGIN

@interface OKCrashReportMetricKitThreadInfo : NSObject

- (instancetype)initWithAddresses:(NSArray<NSNumber *> *)addresses
                          offsets:(NSArray<NSNumber *> *)offsets
                      binaryNames:(NSArray<NSString *> *)binaryNames
                      asTriggered:(BOOL)isTriggered;

@property (nonatomic, readonly) NSArray<NSNumber *> *addresses;
@property (nonatomic, readonly) NSArray<NSNumber *> *offsets;
@property (nonatomic, readonly) NSArray<NSString *> *binaryNames;
@property (nonatomic, readonly) BOOL isTriggered;

@end

NS_ASSUME_NONNULL_END

//
//  OKCrashReportMetricKitReportInfo.h
//  OKTracer
//
//  Created by david.chupreev on 12.12.2023.
//

#import <Foundation/Foundation.h>

#if __has_include(<CrashReporter/OKCrashReportMetricKitThreadInfo.h>)
#import <CrashReporter/OKCrashNamespace.h>
#import <CrashReporter/OKCrashReportMetricKitThreadInfo.h>
#else
#import "OKCrashReportMetricKitThreadInfo.h"
#import "OKCrashNamespace.h"
#endif

NS_ASSUME_NONNULL_BEGIN

@interface OKCrashReportMetricKitReportInfo : NSObject

- (instancetype)initWithThreads:(NSArray<OKCrashReportMetricKitThreadInfo *> *)threads
                       metaInfo:(NSDictionary *)metaInfo
                     isNonFatal:(BOOL)isNonFatal
     triggeredThreadIsAvailable:(BOOL)triggeredThreadIsAvailable
             applicationVersion:(NSString *)applicationVersion
               applicationBuild:(NSString *)applicationBuild;

@property (nonatomic, readonly) NSArray<OKCrashReportMetricKitThreadInfo *> *threads;
@property (nonatomic, readonly) NSDictionary *metaInfo;
@property (nonatomic, readonly) BOOL isNonFatal;
@property (nonatomic, readonly) BOOL triggeredThreadIsAvailable;
@property (nonatomic, readonly) NSString *applicationVersion;
@property (nonatomic, readonly) NSString *applicationBuild;

@end

NS_ASSUME_NONNULL_END
